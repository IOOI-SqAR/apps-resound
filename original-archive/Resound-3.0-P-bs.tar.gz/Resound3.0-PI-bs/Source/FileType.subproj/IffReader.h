/** IffReader.m		// Abstract generig base class for reading chunk based file formats
                        // such as AIFF, IFF/8SVX and WAVE
Copyright (c) 1998 Jerome Genest.  All rights reserved.
jgenest@gel.ulaval.ca

This source code was insprired from and thus contains parts from:

-C++ framework (in "A Programmer�s guide to sound, Addison-Wesley)
 by Tim Kientzle Copyright 1997.  All rights reserved.

Permission to use, copy, modify, and distribute this material for any
NON-PROFIT purpose is hereby granted. Commercial use of this material
is granted only with the sole permission of Jerome Genest. Both are
provided that this permission notice appear in all source copies, and that
the author's name shall not be used in advertising or publicity pertaining
to this material without the specific, prior written permission of the author.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#import "AudioFileReader.h"


#define CHUNKNAME(a,b,c,d) (                 \
    (((unsigned long)(a)&255)<<24)          \
  + (((unsigned long)(b)&255)<<16)          \
  + (((unsigned long)(c)&255)<<8)           \
  + (((unsigned long)(d)&255)))


typedef struct
 {
unsigned long type; // Type of chunk
unsigned long size; // Size of chunk
unsigned long remaining; // Bytes left to read
BOOL isContainer;   // true if this is a container
unsigned long containerType; // type of container
} iffchunkInfo;

@interface IffReader : AudioFileReader
{
unsigned char *formatData;
unsigned long formatDataLength;

// chunk stack
iffchunkInfo chunk[5];

int currentChunk; // top of stack
}
@end