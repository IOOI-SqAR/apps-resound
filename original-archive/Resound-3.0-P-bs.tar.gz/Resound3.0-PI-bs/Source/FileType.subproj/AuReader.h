/** auReader.m
Copyright (c) 1998 Jerome Genest.  All rights reserved.
jgenest@gel.ulaval.ca

This source code was insprired from and thus contains parts from:

-C++ framework (in "A Programmer�s guide to sound, Addison-Wesley)
 by Tim Kientzle Copyright 1997.  All rights reserved.

Permission to use, copy, modify, and distribute this material for any
NON-PROFIT purpose is hereby granted. Commercial use of this material
is granted only with the sole permission of Jerome Genest. Both are
provided that this permission notice appear in all source copies, and that
the author's name shall not be used in advertising or publicity pertaining
to this material without the specific, prior written permission of the author.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#import "AudioFileReader.h"
#import <stdio.h>
#import <AppKit/AppKit.h>
//#import <SoundKit/sound.h>
#import "SoundFormats.h"

//#include "compress.h"
//#include "aplayer.h"

/* Magic numbers used in Sun and NeXT audio files */
#define SUN_MAGIC 	((int)0x2e736e64)	/* Really '.snd' */
#define SUN_INV_MAGIC	((int)0x646e732e)	/* '.snd' upside-down */
#define DEC_MAGIC	((int)0x2e736400)	/* Really '\0ds.' (for DEC) */
#define DEC_INV_MAGIC	((int)0x0064732e)	/* '\0ds.' upside-down */

#define SUN_HDRSIZE	24			/* Size of minimal header */
#define SUN_HDRSIZE	24			/* Size of minimal header */
#define SUN_UNSPEC	((unsigned)(~0))	/* Unspecified data size */

BOOL isAuFile(FILE *file);

@interface AuReader: AudioFileReader 
{
long dataLength;
long originalDataLength;
BOOL headerRead; // true if header has already been read
int headerChannels; // channels from header
int headerRate; // sampling rate from header

BOOL needToSwap;
 
}

-initFromFile:(FILE *)theFile;
- (void)dealloc;

-(long) dataLength;
-(short) outputFormat;
-(short) inputFormat;

- (long) getSamples:(void*)samplesBuffer forSize:(long)size;
- (long) readBytes:(void*)bytesBuffer forSize:(long)size;

- (void) readHeader;

- (void) minMaxSamplingRate:(long*) min :(long*) max: (long*) prefer;
- (void) minMaxChannels:(long*) min :(long*) max: (long*) prefer;
@end




